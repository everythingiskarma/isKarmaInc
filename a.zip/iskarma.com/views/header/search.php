  <div id="clearSearch" class="icon-backspace"></div>
  <div id="searchInput" class="icon-search">
    <input type="text" name="search" alt="Search" placeholder="Search anything on this site...!" autocomplete="off" autofocus />
  </div>
  <div id="searchFiltersToggle" class="active icon-left"></div>
  <div id="searchFilters">
    <ul>
      <li>
        <h3>Filter Categories</h3>
        <div class="filterCat">
        </div>
      </li>
      <li>
        <h3>Related Keywords</h3>
        <div class="relatedKeywords">
          show some related keywords here
        </div>
      </li>
      <li>
        <h3>Suggested</h3>
        <div class="filterSuggested">
          show some suggested content titles here
        </div>
      </li>
      <li>
        <h3>Popular</h3>
        <div class="filterPopular">
          show some popular content titles here
        </div>
      </li>
    </ul>
  </div>
  <div id="searchResults"></div>
  <div id="searchResultDetails">
    <div id="returnToResults" class="icon-left"></div>
    <div id="searchPerspective"></div>
  </div>
  <div id="searching" class="icon-spinner1"></div>
