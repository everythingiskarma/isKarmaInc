<carousel>
  <ul>
    <li class="slideWelcome">
      <logo>
        <one class="dot no-dots"></one>
        <two class="dot no-dots"></two>
        <three class="dot no-dots"></three>
        <four class="dot no-dots"></four>
        <five></five>
        <six></six>
        <seven></seven>
        <eight></eight>
      </logo>
    </li>

    <li class="slideAboutUs">
      slide about isKarma Inc
    </li>

    <li class="slideWhatWeDo">
      slide about what we do
    </li>

    <li class="slidePrivacyPolicy">
      slide about privacy policy
    </li>

    <li class="slideTermsOfService">
      slide about terms of service
    </li>

    <li class="slideRecycle">
      Recycling integrated into
    </li>

    <li class="slideBin">
      slide on waste Management
    </li>

    <li class="slideEarth">
      slide on environment Protection
    </li>

    <li class="slideBicycle">
      slide on bicycling
    </li>

    <li class="slideTree">
      slide on tree plantation
    </li>

    <li class="slideDroplet">
      slide on clean water
    </li>

    <li class="slideActivityCalendar">
      slide on activity calendar
    </li>

    <li class="slideAndroid">
      slide on android app
    </li>

    <li class="slideGithub">
      slide on github
    </li>

    <li class="slideMediaCalendar">
      slide on media calendar
    </li>

    <li class="slideYoutube">
      slide on youtube
    </li>

    <li class="slidePencil">
      slide on pencil
    </li>

    <li class="slideSupport">
      slide on support helpdesk
    </li>

    <li class="slideDocs">
      slide on Research Documentation and Knowledge Base
    </li>

    <li class="slideBug">
      slide on bug reporting
    </li>

    <li class="slideShare">
      slide on sharing the site
    </li>

    <li class="slideReview">
      slide on writing a review
    </li>

    <li class="slideMediaCalender">
      slide on media calendar
    </li>

    <li class="slideLocation">
      slide on location
    </li>

    <li class="slideEnvelope">
      slide on quick contact
    </li>

    <li class="slideProtonMail">
      slide on proton mail
    </li>

    <li class="slideQrCode">
      slide on qr code
    </li>

    <li class="slideLifebuoy">
      slide on support HelpDesk
    </li>

    <li class="slideSkype">
      slide on skype
    </li>

    <li class="slideViber">
      slide on viber
    </li>

    <li class="slideSignal">
      slide on signal
    </li>

    <li class="slidePhone">
      slide on phone
    </li>
  </ul>
</carousel>
