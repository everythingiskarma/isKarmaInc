<toggle class="toggles" title="show / hide toggles"></toggle>
<toggle id="sidebarToggle" class="sidebar icon-th-list" title="display the sidebar"></toggle>

<ul id="togglebox">

  <toggle id="writeToggle" class="write icon-pencil inv" title="write a new post/article"></toggle>

  <toggle id="notificationsToggle" class="notifications icon-msg inv" title="view system notifications and messages"></toggle>

  <toggle id="accountToggle" class="account icon-user inv" title="manage your account"></toggle>

  <toggle id="searchToggle" class="search icon-search inv" title="Search anything on this site...!"></toggle>

  <toggle id="efs" class="efs icon-fs inv" title="enter/exit full screen mode"></toggle>

</ul>

<toggle id="articleToggle" class="article icon-left" title="show/hide article"></toggle>
