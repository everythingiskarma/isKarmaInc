<sidebar>
  <img class="sidebar-logo" src="iskarma.com/logo-iskarma-com.png" />
  <ul>
    <li id="home">
      <span class="icon-home"></span>
      <a title="Return to the home page">Home</a>
    </li>
    <li id="about-us">
      <span class="icon-info"></span>
      <a title="Get to know a bit about us and our work">About</a>
    </li>
    <li id="what-we-do">
      <span class="icon-office"></span>
      <a title="View our services and current projects">What We Do!</a>
    </li>
    <li id="where-we-are">
      <span class="icon-location"></span>
      <a title="Contact us or visit our office">Where We Are</a>
    </li>
    <li id="contact-support">
      <span class="icon-support"></span>
      <a title="Contact support helpdesk">Support</a>
    </li>
    <li id="privacy-policy">
      <span class="icon-eye-blocked"></span>
      <a title="View our privacy policy">Privacy Policy</a>
    </li>
    <li id="terms-of-service">
      <span class="icon-shield"></span>
      <a title="View terms of services">Terms of Service</a>
    </li>
    <li id="credits">
      <span class="icon-star-o"></span>
      <a title="View terms of services">Credits</a>
    </li>
  </ul>
</sidebar>
