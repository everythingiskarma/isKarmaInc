<div class="light">
  <h1>A Haystack Of Zombie Businesses</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        As I seek my first client to consult and share my knowledge with, I am also trying to spot opportunities for building a network of earth friendly businesses. A network that will be able to interoperate and  exchange services as a harmonious collective.
      </p>
      <p>
        The idea is, to have all the service providers, on a common platform, that would be able to transform any existing business into a carbon neutral and a sustainable entity.
      </p>
      <p>
        This platform would encompass innovators, engineers, manufacturers, suppliers, contractors, service providers and the likes. They will be part of a complete solution that is flexible, scalable and equipped to cater to a challenge of any size.
      </p>
      <p>
        Common sense tells me that I should be targeting companies that are most environmentally unfriendly. Beat the drums of awareness and prey on their guilt. Easy sell, right? Well, maybe!
      </p>
      <p>
        But the fact that they are still in business and not moved by the dire consequences of their actions, presents my first challenge. I have to educate them and hope that they have a soul, and that they will acknowledge and accept help where it is needed.
      </p>
      <p>
        I'm motivated by the chance finding of a rare needle in this haystack of zombie businesses. The ones that have realized their responsibility towards mother Earth and are mending their ways towards its restitution.
      </p>
    </section>
  </content>
</div>
