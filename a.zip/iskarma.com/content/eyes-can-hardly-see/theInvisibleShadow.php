<div class="light">
  <h1>The Invisible Shadow</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        There is a phantom force that I feel perpetually surrounded by. It's watching me and everything I do. It follows me around everywhere I go. It communicates with me indirectly. It's almost as if it can read my thoughts. Almost. Most of the time I try to block it out by simply putting on my headphones and going about my business. But sometimes, it is such a sensory overload that I feel my natural self gets trapped in trying to understand why.
      </p>

      <p>
        I have no name for it, but I refer to it as "the beast" or "the eye" or the "all seeing eye". It's evil. I am certain of that. My privacy is invaded and I can not complain because I don't think anyone would understand it. The presence is so overwhelming, that I feel absolutely powerless and defenseless.
      </p>

      <p>
        A question for everyone else who has experienced it. Are you okay with the awareness of their presence. Being okay, is symbolic of allegiance to the devil, generally expressed by making a 666 hand sign, with your thumb and your index finger joined together.
      </p>

      <p>
        If you are okay, then they own your soul and if it's my soul that they want, I can see the blatant failure in their desperation and the lengths they are willing to go to. My soul is only going to one place, and that is heaven, and that is only when I die. Until then, we are at war, and you can bank on that!
      </p>

      <p>
        Rest of you puppets! Find it within yourselves and fight back! If not with force than merely by bearing the pain they put you through. Your soul is worth it!
      </p>

    </section>
  </content>
</div>
<intro>
  A short brief about the people who have become evil and live in the shadows and spy on people without any regard for their privacy or the effect of their presence on our state of mind.
</intro>
