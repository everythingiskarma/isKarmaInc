<div class="light">
  <h1>Supreme Manipulations</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        The trap is, you submit to it, without realizing it. There is a secret war going on to control your minds. Who is behind it is anybody's guess but I'll stick with calling it The Eye.
      </p>

      <p>
        When you are conscious about your surroundings and paying attention to detail, you start connecting the dots. If you learn to see the picture within the picture, you might discover another dimension of existence.
      </p>

      <p>
        There is a whole nother world entangled within your everyday things and a secret language that they use to communicate with the ones that have been initiated.
      </p>

      <p>
        Now while this might sound ludacris to a commoner, you have to know it to believe it. It's such a clever trick, that you can't help but be curious and that's all the opening they need.
      </p>

      <p>
        They are constantly spying on us and they want us to be okay with it. They want us to be aware of it and even help them enslave others. It's like a contagious phenomena. They're building an army of ant's and anyone who resists gets swarmed by their foot soldiers. They prey on your fears and relentlessly put pressure on your weaknesses until you give in and join them.
      </p>

      <p>
        Most people hardly even realize the fact that they're being manipulated. All it takes, is simply offering them help, with something they're struggling with. Show concern and they'll gladly accept the bait, without even realizing the invasion of their privacy.
      </p>

      <p>
        They are masters of manipulation and for a mere mortal it is too easy to get trapped and become their slave. Fear, force and the ability to deny are tools of their modus operandi. They wield such power that they can change your mindsets, beliefs, behaviour and often blur the lines between right and wrong, moral and immoral, truth and lies.
      </p>
      <p>
        They make you helpless and then they pretend to rescue you from the situation they put you in, in the first place. They will make you do what they want you to do and sadly you will belive that it was out of your own free will. You may even feel indebted and accept obedience in return. Hence, making you "just another brick in the wall".
      </p>

    </section>
  </content>
</div>
<intro>
  This bit is about being conscious and aware of when the evil eye is trying to assert their dominance over you through manipulation. But if you resist and keep fighting i promise you, your soul will endure. Otherwise, you will end up in their abyss of sin and darkness.
</intro>
