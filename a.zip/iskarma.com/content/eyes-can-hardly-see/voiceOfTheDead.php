<div class="light">
  <h1>Voice Of The Dead</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        I would buy food or give some change to an old man sitting on a street corner and I would find myself swarmed by helpless beggars at every crossroad.
      </p>

      <p>
        I would suggest someone not to burn wood as it causes air pollution and I would find families of daily wage workers burning wood twice a day to cook food, settling down right outside my house.
      </p>

      <p>
        I would be dead broke with only a handful of money and I would get random calls from charities asking for donations.
      </p>

      <p>
        I would walk up to a stranger and tell him not to smoke because it's bad for health and I would be swarmed with people smoking or chewing tobacco around me.
      </p>

      <p>
        My feet would be hurting from a bow legs problem (thanks to the evil eye) and I would find all the buses and metro trains running full without an empty seat and me having to stand all through the journey.
      </p>

      <p>
        The more I struggle the stronger the force against me seems to get. It is as if they are toying with me. Mocking me in a heartless show of strength as if they are trying to make me feel someone else's pain.
      </p>

      <p>
        Or perhaps they are simply using me as a medium to make a statement to a higher authority who is watching over me. They are putting me through misery that I don't deserve and want me to cry out loud and be their voice.
      </p>

      <p>
        I will not sing for you. You do not inspire me. You are evil. You can break my body but my soul is mine to keep. Remember, God is watching. He will not reason with you. He will simply deliver justice.
      </p>
    </section>
  </content>
</div>
<intro>
  This post reveals how the evil eye incessantly tries to manipulate us into submission. With the forces they control, they create so much pressure on you to give up your freedom and become "okay" and accept their servitude.
</intro>
