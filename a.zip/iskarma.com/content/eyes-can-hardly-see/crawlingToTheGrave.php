<div class="light">
  <h1>Crawling to the Grave</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        Believe me when I say this, they are pure evil. They have corrupted everything. It is total anarchy and it is all swept under the rug by the media.
      </p>

      <p>
        Those who would stake their lives to bring out the truth might find themselves strategically cornered and reduced to struggle for survival. And that's if they're lucky.
      </p>

      <p>
        It is beyond me, how they would allow selling cigarettes and tobacco, even when they know it is a potential cause for cancer. Population control, perhaps! And the irony is, people still buy it, ignoring clear warnings on the covers. They're all zombies, already dead inside, just crawling to their graves.
      </p>

      <p>
        Almost a decade of the best part of my life is lost to it and I'm still struggling to recover from it.
        I have been out of a job trying to start my own business for quite a while now. I've been living on pocket money from my dad's pension and I feel guilty about that too. That is money coming from tax collected from selling such things. It's like a free meal I never seem to be able to digest.
      </p>

      <p>
        You would go out and mass murder revolutionists in other countries, but build safe haven for multi billion worth industries that are killing your people from within. And don't even begin to give me a justification for that.
      </p>

      <p>
        You are cowards, oppressing the weak and serving the evil overlords.
      </p>

      <p>
        The whole world is in utter chaos and no authorities ever saw it worth saving from these monsters. The forces of good never rose. The savior never came. Not now, not ever!
      </p>

    </section>
  </content>
</div>
<intro>
  This post is a cry from a place of darkness, disgust, anger and helplessness. The systems that are meant to govern the policies of the world and ensure the well-being of human kind are responsible for allowing the evil in our lives. They call it "the necessary evil".
</intro>
