<div class="light">
  <h1>Obey! They Know Better</h1>
  <content>
    <h2></h2>
    <section>

      <p>
        It is not rocket science to defeat an enemy! All you need to know is a weakness and then simply direct your strategy towards making it worse! Time will do the rest! The art of war is less about conquering what is outside and more about fighting what's within.
      </p>

      <p>
        When you possess ability that is far too overpowering over someone, then war just becomes education. Like how I am interfaced with my oppressor. My body is taken hostage and my soul is the ransom. It's about applying relentless pressure and waiting for the moment when I break and surrender. It's just a matter of time. The test of my patience and my capacity to bear the torment.
      </p>

      <p>
        I find comfort in pain, it purifies my conscience. It's retribution that is teaching me to forgive myself. But, it's only momentary, for there is no such thing as true forgiveness.
      </p>

      <p>
        I never see a doctor. I let my sickness be. They put it in me and they will get it out when my time is done. That's wishful thinking, I know! Even self destructive, but believe me, it's not. Doctors are evil. Perhaps more than the enemy himself. It works like a tag team. The eye makes you sick and then you see a doctor who will keep you sick and even make you pay for it.
      </p>

      <p>
        It's just business! A heartlessly flawless setup that controls the entire world. It's easy to fall prey to it and when you lay down your arms and obey, you are only making it easier for them to manipulate you.
      </p>

      <p>
        Fight back. Bear the pain. Rebel! We will find a way!
      </p>

    </section>
  </content>
</div>
<intro>
  This post is about my way of dealing with physical, mental and emotional torment by the evil eye. Even when you are helpless and denied everything that matters to you, you still have your soul. Live for that. Fight for that!
</intro>
