<div class="light">
  <h1>The Mirror Game</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        Subtle or clear justifications for invading your privacy are in itself an acknowledgement of the fact, that "the evil eye" is fundamentally wrong.
      </p>

      <p>
        Most of commercial media today is either owned by them or operates under their influence. The news, the TV networks, the movie business everything is corrupted. How do I know you might ask? Well, my only response to that would be, "because I pay attention"!
      </p>

      <p>
        Next time you see a politician, a news anchor, a movie star or even your office colleague for that matter, throwing up a 666 hand sign, rest assured that they're only babbling what their evil masters dictate.
      </p>

      <p>
        I am often faced with people mimicking my life, almost as if they were trying to say that "I can see you, but you can't see me, and you can't do anything about it"!
      </p>

      <p>
        That might even be true. How can you fight an enemy you cannot see. It is mostly innocent or unaware people, who are too weak to put up a fight, that they use as bait to relay their messages.
      </p>

      <p>
        When you face an enemy you can not see, you have little or no choice in the matter. But that certainly can not be the excuse to become like them and drown the world in darkness.
      </p>

      <p>
        I understand your plight. But there is no mercy in my heart for those who will not fight for their own soul. Not that I am asking you to choose pain and misery over slavery, I am just saying that without soul it isn't life at all.
      </p>

      <p>
        They're like mirrors, trying to make you realize your own behavior as if they are trying to help you. And in the sea of such mirrors you only see what you want to see. Hate or love whatever you see is what you want to see. But if you see either you lose and they're justified.
      </p>

    </section>
  </content>
</div>
<intro>
  This post is a personal note about not getting trapped in the world of darkness where you live in fear of the unknown and lose the light of life and being true.
</intro>
