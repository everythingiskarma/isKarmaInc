<div class="light">
  <h1>Fight The Fight</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        It won't let up. It is convinced that it is the only way and I am merely delaying the inevitable. I will knowingly or unknowingly become a part of it. Perhaps I already am. Sometimes I wonder if I am even worth such effort for it to so tirelessly pursue me, even as a subject of study.
      </p>

      <p>
        It's psychological warfare, my grit is being tested, and I am unwaveringly convinced otherwise.
      </p>

      <p>
        You might have noticed that I have started referring to the enemy as "it". The reason being, I have a strong feeling that it is an AI coupled with human intelligence. If I am right and it is a futuristic weapon of mind control being deployed in real world, then I am both supremely impressed and utterly uninterested in the fight.
      </p>

      <p>
        Maybe it is simply trying to teach me but doesn't know how to. With my reservations and adamant thinking it just isn't able to dissolve me into the collective fluid of generic humanity that it can control.
      </p>

    </section>
  </content>
</div>
<intro>
  This post is a hunch about who are pulling strings behind the curtains in this futuristic war of mind control and mass manipulation.
</intro>
