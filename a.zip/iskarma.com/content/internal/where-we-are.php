<div class="light">
  <h1>Where We Are</h1>
  <content id="contactUs">

    <h2>Contact</h2>
    <section class="center">
      <a href="tel:+9779703799299">
        <span class="icon-phone"></span>
        <title>+977 970-379-9299</title>
      </a>
      <a href="skype:iskarma@proton.me?call">
        <span class="icon-skype"></span>
        <title>Call on Skype</title>
      </a>
      <a href="viber://chat?number=%2B9779703799299">
        <span class="icon-viber"></span>
        <title>Call on Viber</title>
      </a>
      <a href="signal://chat?number=%2B9779703799299">
        <span class="icon-signal1"></span>
        <title>Call on Signal</title>
      </a>
    </section>

    <h2>Email</h2>
    <section class="center">
      <a type="email" href="mailto:support@iskarma.com">
        <span class="icon-mail"></span>
        <title>Send Us a Mail</title>
      </a>
      <p style="text-transform:lowercase">support@iskarma.com</p>
    </section>

    <h2>Map Location</h2>
    <section>

    </section>

    <h2>Registered Address</h2>
    <section class="center">
      <p>A-1, Near Balkunja School, <br>Bhatke Pul, Tokha, <br>Kathmandu - 44600,<br> Bagmati, Nepal</p>
    </section>

  </content>
</div>
