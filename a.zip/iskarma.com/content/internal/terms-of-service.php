<div class="light">
  <h1>Terms Of Service</h1>
  <content id="">
    <h2>Home</h2>
    <section>
    </section>
  </content>
</div>
