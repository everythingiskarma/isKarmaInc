<div class="light">
  <h1>Economy Of The Earth</h1>
  <content>
    <h2></h2>
    <section>
      <p>
        Laws of nature are irrefutable and unforgiving. Perhaps, more than the laws laid down for our social conduct. Our conduct against nature has profound consequences.
      </p>
      <p>
        At the risk of being frowned upon for scaremongering, I am merely trying to draw attention to the devil that is quietly paying us dividends now but only by stealing from our future.
      </p>
      <p>
        Civilizations have risen and kingdoms have soared. From stone age to the AI (Artificial Intelligence) age. The cost is yet being paid and a debt being constantly accrued, for the only way, is the way forward.
      </p>
      <p>
        The inevitable already seems to be upon us. Living in cities is far from healthy, as we breathe in pollution each day and eat food without quality control leaving us vulnerable and at the mercy of mother nature. Mother nature, that is sacrificing herself each day, bit by bit, to allow us to cherish this gift of life.
      </p>
      <p>
        As many a negative thoughts rummage through my mind and I feel like complaining with incessant fury, I would like to shift focus on to the perspective that I believe holds the key to sustainability.
      </p>
      <p>
        Building the future in tune with and to rehabilitate the ecosystem of the planet. There is great opportunity for early adopters who are cognizant of the fact and are working to heal the planet. Time will reveal in all its might a transition towards an economy centered around this fact.
      </p>
      <p>
        Let's build a better world, a planet that will endure through the recovery period and a future for our generations to come.
      </p>
    </section>
  </content>
</div>
