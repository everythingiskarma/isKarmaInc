  // get current domain
  var domain = window.location.hostname;
  //var domain = "www.iskarma.com";
  domain = domain.replace(/^www\./, '');
